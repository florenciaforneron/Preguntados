<?php

//include("third-party/Conectarbd.php");
include('third-party/phpqrcode/qrlib.php');
class lobbyController
{
    private $render;
    private $model;

    public function __construct($render, $model)
    {
        $this->render = $render;
        $this->model = $model;
    }

    public function list()
    {
        if (!isset($_SESSION["usuario"]))
            Redirect::to("/home");


        $data = ['datosUsuario' => $this->model->getDatosDelUsuario($_SESSION['usuario'])];


        if ($_SESSION["idRol"] == 1) {
            $this->render->printView('admin', $data);
        }

        if ($_SESSION["idRol"] == 2) {
            $this->render->printView('editor', $data);
        }

        if ($_SESSION["idRol"] == 3) {
            $data['ranking'] = $this->model->getRanking();
            $this->render->printView('lobby', $data);

            $dir = 'public/qr/';

            if (!file_exists($dir)) {
                mkdir($dir);
            }

            $userName = $this->model->getDatosDelUsuario($_SESSION['usuario']);
            if (!empty($userName) && isset($userName[0]['nombre_usuario'])) {
                $nombreUsuario = $userName[0]['nombre_usuario'];

            } else {

                echo 'El nombre de usuario no está disponible.';
            }

            $filename = $dir . $nombreUsuario . '.png';

            $datosUsuario = $this->model->getDatosDelUsuario($nombreUsuario);

            if ($datosUsuario) {

                var_dump($datosUsuario);
                $cadenaDatosUsuario = '';

                foreach ($datosUsuario as $dato) {
                    $cadenaDatosUsuario .= "Usuario: " . (isset($datosUsuario[0]['nombre_usuario']) ? $datosUsuario[0]['nombre_usuario'] : 'No disponible') . "\n";
                    $cadenaDatosUsuario .= "Nombre Completo: " . (isset($datosUsuario[0]['nombreCompleto']) ? $datosUsuario[0]['nombreCompleto'] : 'No disponible') . "\n";
                    $cadenaDatosUsuario .= "Puntaje Máximo: " . (isset($datosUsuario[0]['puntaje_max']) ? $datosUsuario[0]['puntaje_max'] : 'No disponible') . "\n";
                }

                QRcode::png($cadenaDatosUsuario, $filename, QR_ECLEVEL_L, 8);

            } else {
                echo 'No se encontraron datos para este usuario.';
            }
        }
    }
   
}